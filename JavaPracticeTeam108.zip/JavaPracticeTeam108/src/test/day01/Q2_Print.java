package test.day01;

public class Q2_Print {
    /*
        ************************************
                "ATM'ye Hosgeldiniz"

             1- Bakiye Sorgulama
             2- Para Yatirma
             3- Para Cekme
             4- Menu'den Cikis

        *************************************
         */
    public static void main(String[] args) {
        System.out.println("************************************" +
                "\n\t\t\"ATM'ye Hosgeldiniz\"\n\n\t" +
                "1- Bakiye Sorgulama\n\t" +
                "2- Para Yatirma\n\t" +
                "3- Para Cekme\n\t" +
                "4- Menu'den Cikis\n\n" +
                "************************************");
    }
}
